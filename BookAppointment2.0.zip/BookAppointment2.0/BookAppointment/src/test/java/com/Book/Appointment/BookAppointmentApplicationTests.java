package com.Book.Appointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
