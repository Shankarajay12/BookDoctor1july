package com.Book.Appointment.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Book.Appointment.entity.User;

@Repository
public interface UserDao extends JpaRepository<User,Integer > {
	
	public	User findByEmailId(String emailId);

}
