package com.Book.Appointment.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Book.Appointment.entity.Appointment;

@Repository
public interface AppointmentDao extends JpaRepository<Appointment, Integer> {


	@Query(value = "SELECT * FROM appointment u WHERE u.user_idfk = ?1",nativeQuery = true)
	public List<Appointment> findAllAppintByid (int id);
	         

}
