package com.Book.Appointment.web.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.Book.Appointment.Service.AppointmentService;
import com.Book.Appointment.Service.UserService;
import com.Book.Appointment.entity.Appointment;
import com.Book.Appointment.entity.User;


@Controller
public class HomeController {


	private boolean userlogin;// boolean variable to be set true if user login 
	
	
	
	@Autowired
	private UserService userService;
	
	
	@Autowired
	private AppointmentService appoint;
	
	int AppointEdit=0;// to hold the id of the appointment which is clicked for the edit
	

	User u =new User();// to hold the object of which n user is logged in since there are n number of user
	
	
	@RequestMapping("/")
	public String MainPage(Model model) {
	model.addAttribute("ulogin", userlogin);//holding the boolean value of user 
	
	if(userlogin==false)
		model.addAttribute("login", true);
	return "index";
	}
	
	@RequestMapping("/service")
	public String service(Model model) {
		if(userlogin==false )
			model.addAttribute("login", true);
		return "service";
	}
	
	
	@RequestMapping("/help")
	public String help(Model model) {
		
		if(userlogin==false)
			model.addAttribute("login", true);
		return "Help";
	}
	
	@RequestMapping("/AboutUs")
	public String AboutUs(Model model) {
		
		if(userlogin==false )
			model.addAttribute("login", true);
		return "AboutUs";
	}
	
	
	@RequestMapping("/viewAppointment") 
	public String ViewAppointment(Model m)
	{
		if(userlogin)// checking if user is still logged in 
		{
			List<Appointment> AllAppointment=appoint.getAllAppointmentByUserID(u.getId());
			
			System.out.println("user id "+u.getId()+" size of list "+AllAppointment.size());
				m.addAttribute("data",AllAppointment);
				return "userDashboard";
		}
		
		return "adminDashboard";
	}
	
	@RequestMapping("/AdminViewAppointment")
	public String AdminViewAppointment(Model m)
	{
		List<Appointment> AllAppointment=appoint.getAllAppointment();
		
		System.out.println("admin dashboard logged in already");
			m.addAttribute("data",AllAppointment);
		
		return "adminDashboard";
	}
	
	@RequestMapping("/login")
	public String Login(Model m)
	{

		if(userlogin){
			if(u.getRole().equalsIgnoreCase("admin")){
				return "AdminDashboardMain";
				
			}
			else {
				return "UserDashboardMain";
			}
	}
	else {
		System.out.println("logout");
		return "login";
	}
	}
	
	@PostMapping("/login")
	public String Login(@RequestParam("email") String email,
			@RequestParam("password") String password,
			@RequestParam("role") String role,Model m,HttpSession session) {
		 u=userService.findUserByEmail(email);
		if(u==null) {
			m.addAttribute("passwordHelp","User Password does not match...");
		}
			 
		else if(u.getEmailId().equals(email) && u.getPassword().equals(password) && u.getRole().equalsIgnoreCase(role))
		{ 
			userlogin=true;
			if(role.equalsIgnoreCase("admin")){
				
				session.setAttribute("admin","Admin Logged in Successfully");
				return "AdminDashboardMain";
				
			}
			else {
				String Usr="welcome "+u.getName();
				session.setAttribute("user",Usr);
				return "UserDashboardMain";
			}
		}
		else {
			System.out.println("Login Credentials not Matched");
			
			m.addAttribute("passwordHelp","User Password does not match...");
			return "login";
		}
		return "login";
	}
	
	@RequestMapping("/registration")
	public String registerPage() {
		return "registration";
	}
	
	@PostMapping("/registration")
	public String Register(
			@RequestParam("name") String name,
			@RequestParam("email") String email,
			@RequestParam("password") String password,
			@RequestParam("city") String city,
			@RequestParam("phone") String Phone,
			@RequestParam("gender") String Gender,
			@RequestParam("state") String state,HttpSession session
			) {
		
		System.out.println(name);
		User user=new User();
		user.setName(name);
		user.setGender(Gender);
		user.setCity(city);
		user.setState(state);
		user.setEmailId(email);
		user.setPassword(password);
	    user.setNumber(Phone);
	    System.out.println(user);
	    userService.setUser(user);
	    session.setAttribute("Register","Registered Successfully!");
		System.out.println("Registered Successfully");
	return "login";
	}
	
	@RequestMapping("/forgetPassword")
	public String forgetPasswordPage() {
		return "forgetPassword";
	}
	
	
	@PostMapping("/forgetPassword")
	public String forgetPassword(@RequestParam("email") String email,
			@RequestParam("password") String password,Model m,HttpSession session) {
		
		User u=userService.findUserByEmail(email);
		if(u==null) {
			System.out.println("User Not Available");
			
			m.addAttribute("emailHelp","Email does not exist...");
			return "login";
		}
		else if(u.getEmailId().equals(email)) {
			u.setPassword(password);
			session.setAttribute("PasswordReset","Password Reset successfully");
			System.out.println("Password Reset Successfully");
			userService.setUser(u);
			m.addAttribute("user", u);
			return "login";
		}
		else {
			System.out.println("Password Not Reseted Successfully");
			m.addAttribute("passwordHelp","Password Reset Unsuccessfull...");
		return "forgetPassword";
		}
	}
	

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		this.userlogin=false;
		
		System.out.println("logout successfully");
		session.setAttribute("message","You Have Been Logged out successfully");
	return "login";
	}
	
	@RequestMapping("/userAddNew")
	public String view()
	{
		return "userAddNew";
	}
	
	@PostMapping("/userAddNew")
	  public String upload(Model model,RedirectAttributes redirectAttributes,
			  @RequestParam("name") String name,
			  @RequestParam("gender") String gender,
			  @RequestParam("date") Date date,
			  @RequestParam("time") String time,
			  @RequestParam("age") int age,
	  		  @RequestParam("city") String city,
	  		  @RequestParam("state") String state,
	  		  @RequestParam("purpose") String purpose
	  		  ,HttpSession session)
			  {
				
		Appointment Appoint=new Appointment();
		
		Appoint.setName(name);
		Appoint.setGender(gender);
		Appoint.setDate(date);
		Appoint.setTime(time);
		Appoint.setAge(age);
		Appoint.setCity(city);
		Appoint.setState(state);
		Appoint.setPurpose(purpose);
		Appoint.setUserIdFK(u.getId());
		
		appoint.BookAppointment(Appoint);
		
			  System.out.println("Appointment Booked succesfully");
			  session.setAttribute("message","Appointment Booked succesfully");
			  
			  redirectAttributes.addFlashAttribute("message", "Failed");
			    redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
			  System.out.println(Appoint.getId());
		  return "userAddNew";
			  }
	
	
	@PostMapping("/removeAppointment")
	public String removeAppointment(@RequestParam("AppointmentId") int id,Model m,HttpSession session) {
		System.out.println("Appointment delete button");
		System.out.println(id);
		Appointment ap=appoint.getAppointment(id);
		appoint.deleteAppointment(id);
		
		String result="Appointment for "+ap.getPurpose()+" deleted successfully";
		session.setAttribute("message",result);
		if(this.userlogin==true) {
			
				//AllCart=cartService.getAllCartProperties(); 

			List<Appointment> AllAppointment=appoint.getAllAppointmentByUserID(u.getId());
			m.addAttribute("data",AllAppointment);
			//m.addAttribute("aemail", aemail);
			System.out.println("if block");
			
			return "userDashboard";
		}
		else {
			System.out.println("else block");
			return "login";
		}
	}
	
	@RequestMapping("/editAppointment")
	public String editAppointmentPage(@RequestParam("AppointmentId") int id,Model m) {
		Appointment pro=appoint.getAppointment(id);
		
	String name=pro.getName();
	int age=pro.getAge();
	String gender=pro.getGender();
	String purpose=pro.getPurpose();
	Date date=pro.getDate();
	String time=pro.getTime();
	String city=pro.getCity();
	String state=pro.getState();
	
		m.addAttribute("name",name);
		m.addAttribute("gender",gender);
		m.addAttribute("age",age);
		m.addAttribute("date",date);
		m.addAttribute("time",time);    
		m.addAttribute("city",city);
		m.addAttribute("state",state);
		m.addAttribute("purpose",purpose);
		
		System.out.println("Appointment selected for edit have id : "+id);
		AppointEdit=id;
		return "editAppointment";
	}
	
	@PostMapping("/editAppointment")
	public String editAppointment(Model m,
			 @RequestParam("name") String name,
			  @RequestParam("gender") String gender,
			  @RequestParam("date") Date date,
			  @RequestParam("time") String time,
			  @RequestParam("age") int age,
	  		  @RequestParam("city") String city,
	  		  @RequestParam("state") String state,
	  		  @RequestParam("purpose") String purpose,HttpSession session) {
		
	
		System.out.println("edit button working...");
		
		
		  
	Appointment pro=appoint.getAppointment(AppointEdit);
			
		  System.out.println("before update");
		  System.out.println(pro);
		
		pro.setName(name);
		pro.setGender(gender);
		pro.setDate(date);
		pro.setTime(time);
		pro.setAge(age);
		pro.setCity(city);
		pro.setState(state);
		pro.setPurpose(purpose);
		
		session.setAttribute("add", "Appointment updated successfully");
		System.out.println("after update Appointment");
		System.out.println(pro);
		
		
		appoint.BookAppointment(pro);
		 System.out.println("Appointmnet Updated... id = "+AppointEdit);
		 if(this.userlogin==true) {
			 List<Appointment> AllAppointment=appoint.getAllAppointmentByUserID(u.getId());
				m.addAttribute("data",AllAppointment);
				System.out.println("Succesfully Edited");
				
				return "userDashboard";
		 }
		 return "login";
	}
	
	
	
}
