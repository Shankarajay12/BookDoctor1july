package com.Book.Appointment.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Book.Appointment.Dao.AppointmentDao;
import com.Book.Appointment.entity.Appointment;



@Service
public class AppointmentService {

	@Autowired
	private AppointmentDao appoint;
	
	public Appointment BookAppointment(Appointment App) {
		return appoint.save(App);
	}
	
	public List<Appointment> getAllAppointment()
	{
		return appoint.findAll();
	}
	
	public List<Appointment> getAllAppointmentByUserID(int id)
	{
		return appoint.findAllAppintByid(id);
	}
	
	public void deleteAppointment(int id)
	{
		 appoint.deleteById(id);
	}
	
	public Appointment getAppointment(int id) {
		Appointment Appo=null;
		try {
			Optional<Appointment> optional=this.appoint.findById(id);
			Appo=optional.get();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return Appo;
	}
	
	
}
