package com.Book.Appointment.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Book.Appointment.Dao.UserDao;
import com.Book.Appointment.entity.User;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;
	
	public User setUser(User u) {
		return userDao.save(u);
	}
	
	public User findUserByEmail(String UserEmail)
	{
		User user=userDao.findByEmailId(UserEmail);
		return user;
	}
	
	
	public List<User> getAllCustomer()
	{
		return userDao.findAll();
	}

	
}
